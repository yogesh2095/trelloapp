import React, { useState, useRef } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import Modal from "react-modal";
import uuid from "uuid/v4";
import get from "lodash/get";
import Teams from "./Teams";
import type { Teams as TeamProps } from "../types";
import styles from "./trelloWrapper.module.scss";

const onDragEnd = (result, teams: TeamProps, setTeams) => {
  if (!result.destination) return;

  const { source, destination, draggableId } = result;

  // draggable id would be card id which is moving

  // source droppable id and dest droppable id will be team ids

  if (source.droppableId !== destination.droppableId) {
    const sourceTeam = get(teams, `${source.droppableId}`, {});
    const destTeam = get(teams, `${destination.droppableId}`, {});
    const cardDetails = get(sourceTeam, `cards.${draggableId}`, {});

    const sourceCards = get(sourceTeam, "cards", {});
    const destCards = get(destTeam, "cards", {});

    delete sourceCards[draggableId];

    const updateSourceTeam = {
      ...sourceTeam,
      cards: {
        ...reArrangeCards(sourceCards),
      },
    };

    const updateDestTeam = {
      ...destTeam,
      cards: {
        ...reArrangeCards({
          ...destCards,
          [draggableId]: {
            ...cardDetails,
          },
        }),
      },
    };

    const updatedTeams = {
      ...teams,
      [source.droppableId]: {
        ...updateSourceTeam,
      },
      [destination.droppableId]: {
        ...updateDestTeam,
      },
    };

    localStorage.setItem("trelloData", JSON.stringify(updatedTeams));

    setTeams(updatedTeams);
  }
};

const reArrangeCards = (cards) => {
  const updatedCards = Object.fromEntries(
    Object.entries(cards).sort(
      ([previousCardId, previousCardDetails], [nextCardId, nextCardDetails]) =>
        new Date(nextCardDetails.creationTime) -
        new Date(previousCardDetails.creationTime)
    )
  );
  return updatedCards;
};

const TrelloWrapper = () => {
  const trelloData = localStorage.getItem("trelloData");
  const [teams, setTeams] = useState(JSON.parse(trelloData) || null);
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState(false);
  const [isAddListModalOpen, setIsAddListModalOpen] = useState(false);
  const [cardTitle, setCardTitle] = useState("");
  const [cardDetails, setCardDetails] = useState("");
  const [listTitle, setListTitle] = useState("");

  const addCardToListId = useRef(null);

  const toggleModal = (listId?: number = null): void => {
    addCardToListId.current = listId;
    setCardDetails("");
    setCardTitle("");
    setIsAddCardModalOpen((isPreviouslyModalOpen) => !isPreviouslyModalOpen);
  };

  const toggleCreateListModal = (): void => {
    setListTitle("");
    setIsAddListModalOpen((isOpenPreviously) => !isOpenPreviously);
  };

  const onAddCardDetails = () => {
    let updatedTeams = {};
    if (teams) {
      updatedTeams = { ...teams };
    }
    if (updatedTeams.hasOwnProperty(addCardToListId.current)) {
      let currentTeamsDetails = updatedTeams[addCardToListId.current];
      const currentCardList = currentTeamsDetails?.cards || {};
      const newCardId = uuid();

      const newCardDetails = {
        title: cardTitle,
        desc: cardDetails,
        creationTime: new Date(),
        id: newCardId,
      };

      currentTeamsDetails = {
        ...currentTeamsDetails,
        cards: {
          ...reArrangeCards({
            ...currentCardList,
            [newCardId]: newCardDetails,
          }),
        },
      };

      updatedTeams = {
        ...updatedTeams,
        [addCardToListId.current]: { ...currentTeamsDetails },
      };
    }
    localStorage.setItem("trelloData", JSON.stringify(updatedTeams));
    setTeams(updatedTeams);
    toggleModal();
  };

  const onCreateList = () => {
    let updatedTeams = {};
    const newTeamId = uuid();
    const newTeam = {};
    newTeam[newTeamId] = {
      teamId: newTeamId,
      name: listTitle,
      cards: [],
    };

    if (teams) {
      updatedTeams = { ...teams, ...newTeam };
    } else {
      updatedTeams = { ...newTeam };
    }
    localStorage.setItem("trelloData", JSON.stringify(updatedTeams));
    setTeams(updatedTeams);
    toggleCreateListModal();
  };

  const onDeleteTeamClick = (listId: number) => {
    let updatedTeams = {};
    if (teams) {
      updatedTeams = { ...teams };
    }
    if (teams && teams.hasOwnProperty(listId)) {
      delete updatedTeams[listId];
    }

    localStorage.setItem("trelloData", JSON.stringify(updatedTeams));
    setTeams(updatedTeams);
  };

  const onCardDeleteClick = (listId: number, cardId: number) => {
    const currentTeam = get(teams, `${listId}`, null);
    const currentCards = get(currentTeam, "cards", null);
    let updatedTeams = {};
    if (teams && currentTeam && currentCards) {
      delete currentCards[cardId];
      updatedTeams = {
        ...teams,
        [listId]: {
          ...currentTeam,
          cards: {
            ...reArrangeCards({
              ...currentCards,
            }),
          },
        },
      };
      localStorage.setItem("trelloData", JSON.stringify(updatedTeams));
      setTeams(updatedTeams);
    }
  };

  const shouldDisableAdd = (): boolean => {
    return !(cardTitle?.trim() && cardDetails?.trim());
  };

  const onInputFieldChange = (field: string, event: SyntheticBaseEvent) => {
    const updatedValue = event.target.value;
    if (field === "title") {
      setCardTitle(updatedValue);
    } else if (field == "desc") {
      setCardDetails(updatedValue);
    } else {
      setListTitle(updatedValue);
    }
  };

  const getAddCardModalDom = () => {
    if (!(isAddCardModalOpen && addCardToListId.current)) {
      return null;
    }

    return (
      <Modal
        isOpen={isAddCardModalOpen}
        onRequestClose={toggleModal}
        className={styles.modalContent}
        overlayClassName={styles.overlayClassName}
      >
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>Add card</div>
          <button className={styles.buttonCTA} onClick={toggleModal}>
            X
          </button>
        </div>
        <div className={styles.modalBody}>
          <div className={styles.inputWrapper}>
            <label className={styles.label}>Title:</label>
            <input
              type="text"
              value={cardTitle}
              onChange={onInputFieldChange.bind(this, "title")}
            />
          </div>
          <div className={styles.inputWrapper}>
            <label className={styles.label}>Description:</label>
            <input
              type="text"
              value={cardDetails}
              onChange={onInputFieldChange.bind(this, "desc")}
            />
          </div>
        </div>
        <div className={styles.modalFooter}>
          <button
            className={styles.buttonCTA}
            disabled={shouldDisableAdd()}
            onClick={onAddCardDetails}
          >
            Add Card
          </button>
        </div>
      </Modal>
    );
  };

  const getAddListModalDom = () => {
    if (!isAddListModalOpen) {
      return null;
    }

    return (
      <Modal
        isOpen={isAddListModalOpen}
        onRequestClose={toggleCreateListModal}
        className={styles.modalContent}
        overlayClassName={styles.overlayClassName}
      >
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>Add List</div>
          <button className={styles.buttonCTA} onClick={toggleCreateListModal}>
            X
          </button>
        </div>
        <div className={styles.modalBody}>
          <div className={styles.inputWrapper}>
            <label className={styles.label}>Title</label>
            <input
              type="text"
              value={listTitle}
              onChange={onInputFieldChange.bind(this, "listTitle")}
            />
          </div>
        </div>
        <div className={styles.modalFooter}>
          <button
            className={styles.buttonCTA}
            disabled={!listTitle?.trim()}
            onClick={onCreateList}
          >
            Add List
          </button>
        </div>
      </Modal>
    );
  };

  const onReorderCards = (result) => {
    onDragEnd(result, teams, setTeams);
  };

  return (
    <>
      <div className={styles.trelloWrapper}>
        {teams ? (
          <DragDropContext onDragEnd={onReorderCards}>
            {Object.entries(teams).map(([teamId, teamDetails], index) => {
              return (
                <Teams
                  key={teamId}
                  onAddCardClick={toggleModal.bind(this, teamId)}
                  onDeleteTeamClick={onDeleteTeamClick.bind(this, teamId)}
                  onCardDeleteClick={onCardDeleteClick.bind(this, teamId)}
                  {...teamDetails}
                  teamId={teamId}
                  index={index}
                />
              );
            })}
          </DragDropContext>
        ) : null}
        <button className={styles.buttonCTA} onClick={toggleCreateListModal}>
          Add List
        </button>
      </div>
      {getAddCardModalDom()}
      {getAddListModalDom()}
    </>
  );
};

export default TrelloWrapper;
