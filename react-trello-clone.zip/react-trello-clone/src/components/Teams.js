// @flow

import React from "react";
import type { Node } from "react";
import { Droppable } from "react-beautiful-dnd";
import classNames from "classnames";
import type { Teams as TeamsProps } from "../types";
import Card from "./Card";
import styles from "./teams.module.scss";

const Teams = (props: TeamsProps): Node => {
  const {
    cards,
    name,
    teamId,
    onAddCardClick,
    onDeleteTeamClick,
    onCardDeleteClick,
  } = props;

  const getListWrapper = (isDragingOver: boolean): string =>
    classNames(styles.cardList, { [styles.draggingCardList]: isDragingOver });

  return (
    <div className={styles.teamsWrapper} key={teamId}>
      <div className={styles.cardsContainer}>
        <Droppable droppableId={teamId} key={teamId}>
          {(provided, snapshot) => {
            return (
              <>
                <div className={styles.headerWrapper}>
                  <span>{name}</span>
                  <span
                    onClick={onDeleteTeamClick}
                    className={classNames(
                      styles.circularIcon,
                      styles.deleteIcon
                    )}
                  >
                    x
                  </span>
                </div>
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className={getListWrapper(snapshot.isDraggingOver)}
                >
                  {Object.entries(cards).map(([cardId, card], index) => {
                    return (
                      <Card
                        key={cardId}
                        provided={provided}
                        snapshot={snapshot}
                        onCardDeleteClick={onCardDeleteClick.bind(this, cardId)}
                        {...card}
                        index={index}
                      />
                    );
                  })}
                  {provided.placeholder}
                </div>
                <div className={styles.footerWrapper}>
                  <span
                    onClick={onAddCardClick}
                    className={classNames(styles.circularIcon, styles.addIcon)}
                  >
                    +
                  </span>
                </div>
              </>
            );
          }}
        </Droppable>
      </div>
    </div>
  );
};

Teams.defaultProps = {
  cards: [],
  name: "",
};

export default Teams;
