// @flow

import React from "react";
import type { Node } from "react";
import { Draggable } from "react-beautiful-dnd";
import classNames from "classnames";
import type { Card as CardProps } from "../types";
import styles from "./card.module.scss";

const Card = (props: CardProps): Node => {
  const {
    provided,
    creationTime,
    desc,
    title,
    snapshot,
    id,
    index,
    onCardDeleteClick,
  } = props;

  let formattedCreationTime = new Date(creationTime);
  formattedCreationTime = formattedCreationTime.toISOString();

  const cardWrapper = classNames(styles.card, {
    [styles.draggingBackground]: snapshot?.isDragging,
  });

  return (
    <div className={styles.card}>
      <Draggable key={id} draggableId={id} index={index}>
        {(provided, snapshot) => (
          <div
            ref={provided?.innerRef}
            {...provided?.draggableProps}
            {...provided?.dragHandleProps}
            style={{
              ...provided?.draggableProps?.style,
            }}
            className={cardWrapper}
          >
            <div className={styles.cardHeaderWrapper}>
              <span>{title}</span>
              <span
                onClick={onCardDeleteClick}
                className={classNames(styles.circularIcon, styles.deleteIcon)}
              >
                x
              </span>
            </div>
            <span>{desc}</span>
            <span>{formattedCreationTime}</span>
          </div>
        )}
      </Draggable>
    </div>
  );
};

export default Card;
