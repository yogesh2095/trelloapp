// @flow

export type Card = {
  title: string,
  desc: string,
  creationTime: Date,
  provided: Object,
  snapshot: Object,
  id: number,
  index: number,
  onCardDeleteClick: (listId: number, cardId: number) => void,
};
