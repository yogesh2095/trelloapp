// @flow

import type { Card } from "./card";

export type Teams = {
  cards?: Object,
  name: string,
  teamId: number,
  onAddCardClick: (listId: number) => void,
  onDeleteTeamClick: (listId: number) => void,
  onCardDeleteClick: (listId: number) => void,
};
