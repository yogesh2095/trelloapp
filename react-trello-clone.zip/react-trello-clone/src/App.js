import React from "react";
import TrelloWrapper from "./components/TrelloWrapper";

function App() {
  return <TrelloWrapper />;
}

export default App;
